#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
RecorderAudioProcessor::RecorderAudioProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true))
{
    backgroundThread.startThread (juce::Thread::Priority::normal);

    auto docs = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory);
    outputFile = docs.getChildFile ("Recorder Output.wav");
}

RecorderAudioProcessor::~RecorderAudioProcessor()
{
    stop();
    backgroundThread.stopThread (2000);
}

void RecorderAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;
    sendScratchBuffer.setSize (2, samplesPerBlock);
}

void RecorderAudioProcessor::releaseResources()
{
    stop();
}

bool RecorderAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo()
        && layouts.getMainInputChannelSet()  == juce::AudioChannelSet::stereo();
}

//==============================================================================
void RecorderAudioProcessor::setOutputMode (OutputMode mode)
{
    if (! isActive.load())
        outputMode = mode;
}

void RecorderAudioProcessor::setOutputFile (const juce::File& file)
{
    if (! isActive.load())
        outputFile = file;
}

void RecorderAudioProcessor::setMMEDeviceName (const juce::String& name)
{
    if (! isActive.load())
        mmeDeviceName = name;
}

juce::StringArray RecorderAudioProcessor::getAvailableMMEDevices()
{
    juce::AudioDeviceManager tempManager;
    juce::OwnedArray<juce::AudioIODeviceType> types;
    tempManager.createAudioDeviceTypes (types);

    for (auto* t : types)
    {
        if (t->getTypeName() == "Windows Audio")
        {
            t->scanForDevices();
            return t->getDeviceNames (false); // false = nombres de salida
        }
    }
    return {};
}

//==============================================================================
void RecorderAudioProcessor::start()
{
    if (isActive.load())
        return;

    samplesProcessed.store (0);

    const bool ok = (outputMode == OutputMode::toFile) ? startFileRecording()
                                                         : startMMERouting();
    isActive.store (ok);
}

void RecorderAudioProcessor::stop()
{
    if (! isActive.load())
        return;

    isActive.store (false);

    if (outputMode == OutputMode::toFile)
        stopFileRecording();
    else
        stopMMERouting();
}

double RecorderAudioProcessor::getElapsedSeconds() const
{
    return currentSampleRate > 0.0 ? (double) samplesProcessed.load() / currentSampleRate : 0.0;
}

//==============================================================================
// ---- Modo archivo ----
bool RecorderAudioProcessor::startFileRecording()
{
    if (outputFile == juce::File())
        return false;

    outputFile.getParentDirectory().createDirectory();
    outputFile.deleteFile();

    std::unique_ptr<juce::FileOutputStream> stream (outputFile.createOutputStream());
    if (stream == nullptr)
        return false;

    juce::WavAudioFormat wavFormat;
    const int bits = static_cast<int> (bitDepth);

    std::unique_ptr<juce::AudioFormatWriter> writer (
        wavFormat.createWriterFor (stream.get(), currentSampleRate, 2, bits, {}, 0));

    if (writer == nullptr)
        return false;

    stream.release(); // el writer ahora es dueño del stream

    const juce::ScopedLock sl (writerLock);
    threadedWriter.reset (new juce::AudioFormatWriter::ThreadedWriter (writer.release(), backgroundThread, 32768));
    activeWriter.store (threadedWriter.get());
    return true;
}

void RecorderAudioProcessor::stopFileRecording()
{
    activeWriter.store (nullptr);
    const juce::ScopedLock sl (writerLock);
    threadedWriter.reset();
}

//==============================================================================
// ---- Modo dispositivo MME ----
void RecorderAudioProcessor::MMEPlaybackCallback::pushSamples (const juce::AudioBuffer<float>& source)
{
    const int numSamples = source.getNumSamples();
    const int numCh = source.getNumChannels();

    int start1 = 0, size1 = 0, start2 = 0, size2 = 0;
    fifo.prepareToWrite (numSamples, start1, size1, start2, size2);

    auto writeChunk = [&] (int destStart, int chunkSize, int sourceOffset)
    {
        for (int ch = 0; ch < ringBuffer.getNumChannels(); ++ch)
        {
            float* dst = ringBuffer.getWritePointer (ch);
            const float* src = numCh > 0 ? source.getReadPointer (juce::jmin (ch, numCh - 1)) : nullptr;

            for (int i = 0; i < chunkSize; ++i)
                dst[destStart + i] = src != nullptr ? src[sourceOffset + i] : 0.0f;
        }
    };

    writeChunk (start1, size1, 0);
    writeChunk (start2, size2, size1);

    fifo.finishedWrite (size1 + size2);
}

void RecorderAudioProcessor::MMEPlaybackCallback::audioDeviceIOCallbackWithContext (
    const float* const*, int, float* const* outputChannelData, int numOutputChannels,
    int numSamples, const juce::AudioIODeviceCallbackContext&)
{
    int start1 = 0, size1 = 0, start2 = 0, size2 = 0;
    fifo.prepareToRead (numSamples, start1, size1, start2, size2);

    for (int ch = 0; ch < numOutputChannels; ++ch)
    {
        if (outputChannelData[ch] == nullptr)
            continue;

        const float* src = ringBuffer.getReadPointer (juce::jmin (ch, ringBuffer.getNumChannels() - 1));
        int idx = 0;
        for (int i = 0; i < size1; ++i) outputChannelData[ch][idx++] = src[start1 + i];
        for (int i = 0; i < size2; ++i) outputChannelData[ch][idx++] = src[start2 + i];
        for (; idx < numSamples; ++idx) outputChannelData[ch][idx] = 0.0f; // underrun -> silencio
    }

    fifo.finishedRead (size1 + size2);
}

bool RecorderAudioProcessor::startMMERouting()
{
    if (mmeDeviceName.isEmpty())
    {
        mmeStatus = "Elegi un dispositivo MME primero";
        return false;
    }

    mmeDeviceManager = std::make_unique<juce::AudioDeviceManager>();
    mmeCallback = std::make_unique<MMEPlaybackCallback>();

    juce::OwnedArray<juce::AudioIODeviceType> types;
    mmeDeviceManager->createAudioDeviceTypes (types);

    int mmeIndex = -1;
    for (int i = 0; i < types.size(); ++i)
        if (types[i]->getTypeName() == "Windows Audio")
            mmeIndex = i;

    if (mmeIndex < 0)
    {
        mmeStatus = "No se encontro el driver MME de Windows";
        mmeDeviceManager.reset();
        mmeCallback.reset();
        return false;
    }

    mmeDeviceManager->addAudioDeviceType (std::unique_ptr<juce::AudioIODeviceType> (types.removeAndReturn (mmeIndex)));
    mmeDeviceManager->setCurrentAudioDeviceType ("Windows Audio", true);

    juce::AudioDeviceManager::AudioDeviceSetup setup;
    mmeDeviceManager->getAudioDeviceSetup (setup);
    setup.outputDeviceName = mmeDeviceName;
    setup.inputDeviceName = {};
    setup.useDefaultInputChannels = false;
    setup.useDefaultOutputChannels = true;
    setup.sampleRate = currentSampleRate;

    auto err = mmeDeviceManager->setAudioDeviceSetup (setup, true);
    if (err.isNotEmpty())
    {
        mmeStatus = "Error: " + err;
        mmeDeviceManager.reset();
        mmeCallback.reset();
        return false;
    }

    mmeDeviceManager->addAudioCallback (mmeCallback.get());
    mmeStatus = "Enviando a " + mmeDeviceName;
    return true;
}

void RecorderAudioProcessor::stopMMERouting()
{
    if (mmeDeviceManager != nullptr && mmeCallback != nullptr)
        mmeDeviceManager->removeAudioCallback (mmeCallback.get());

    mmeDeviceManager.reset();
    mmeCallback.reset();
    mmeStatus = "Detenido";
}

//==============================================================================
void RecorderAudioProcessor::sendCurrentBlock (const juce::AudioBuffer<float>& toSend, int numSamples)
{
    if (outputMode == OutputMode::toFile)
    {
        if (auto* writer = activeWriter.load())
        {
            writer->write (toSend.getArrayOfReadPointers(), numSamples);
            samplesProcessed.fetch_add (numSamples);
        }
    }
    else if (mmeCallback != nullptr)
    {
        mmeCallback->pushSamples (toSend);
        samplesProcessed.fetch_add (numSamples);
    }
}

//==============================================================================
void RecorderAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numSamples = buffer.getNumSamples();
    const int numCh = buffer.getNumChannels();

    if (numCh > 0) peakL.store (buffer.getMagnitude (0, 0, numSamples));
    if (numCh > 1) peakR.store (buffer.getMagnitude (1, 0, numSamples));

    if (isActive.load())
    {
        const float gainLin = juce::Decibels::decibelsToGain (sendGainDb.load());
        const auto monitor = monitorMode.load();

        if (monitor == MonitorMode::original)
        {
            // Enviamos una copia con ganancia aplicada, sin tocar lo que escucha el usuario.
            sendScratchBuffer.setSize (buffer.getNumChannels(), numSamples, false, false, true);
            sendScratchBuffer.makeCopyOf (buffer, true);
            sendScratchBuffer.applyGain (gainLin);
            sendCurrentBlock (sendScratchBuffer, numSamples);
            // 'buffer' queda intacta -> el usuario escucha el original sin ganancia.
        }
        else
        {
            buffer.applyGain (gainLin);
            sendCurrentBlock (buffer, numSamples);

            if (monitor == MonitorMode::muted)
                buffer.clear(); // se sigue transmitiendo, pero no suena localmente
            // si es 'transmitted', 'buffer' ya quedó con la ganancia aplicada y se escucha así.
        }
    }
    // Si no está activo: pass-through puro, sin tocar nada.
}

//==============================================================================
void RecorderAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    juce::MemoryOutputStream stream (destData, true);
    stream.writeString (outputFile.getFullPathName());
    stream.writeInt (static_cast<int> (bitDepth));
    stream.writeInt (static_cast<int> (outputMode));
    stream.writeString (mmeDeviceName);
    stream.writeFloat (sendGainDb.load());
    stream.writeInt (static_cast<int> (monitorMode.load()));
}

void RecorderAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    juce::MemoryInputStream stream (data, static_cast<size_t> (sizeInBytes), false);

    auto path = stream.readString();
    if (path.isNotEmpty())
        outputFile = juce::File (path);

    bitDepth = static_cast<BitDepth> (stream.readInt());

    if (! stream.isExhausted())
        outputMode = static_cast<OutputMode> (stream.readInt());

    if (! stream.isExhausted())
        mmeDeviceName = stream.readString();

    if (! stream.isExhausted())
        sendGainDb.store (stream.readFloat());

    if (! stream.isExhausted())
        monitorMode.store (static_cast<MonitorMode> (stream.readInt()));
}

//==============================================================================
juce::AudioProcessorEditor* RecorderAudioProcessor::createEditor()
{
    return new RecorderAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new RecorderAudioProcessor();
}
