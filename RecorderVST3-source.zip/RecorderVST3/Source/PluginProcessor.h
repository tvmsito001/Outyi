#pragma once
#include <JuceHeader.h>

/**
    Recorder — plugin de utilidad que puede:
      a) grabar el canal/bus donde está insertado a un archivo WAV, o
      b) rutear ese mismo audio en vivo hacia un dispositivo de salida MME
         de Windows (por ejemplo VB-CABLE), para que otro programa como
         OBS pueda capturarlo como si fuera una entrada de audio del sistema.

    Incluye control de ganancia para lo que se envía, y un selector de
    monitoreo para elegir qué escuchás vos por tus parlantes/interfaz
    mientras transmite: el original (bypass), lo mismo que se está
    transmitiendo (con la ganancia aplicada), o silencio total (mute local,
    pero la transmisión sigue activa).
*/
class RecorderAudioProcessor : public juce::AudioProcessor
{
public:
    RecorderAudioProcessor();
    ~RecorderAudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Recorder"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    // ---- Modo de salida ----
    enum class OutputMode { toFile, toMMEDevice };
    void setOutputMode (OutputMode mode);
    OutputMode getOutputMode() const { return outputMode; }

    // ---- Modo archivo ----
    void setOutputFile (const juce::File& file);
    juce::File getOutputFile() const { return outputFile; }

    enum class BitDepth { bit16 = 16, bit24 = 24, bit32float = 32 };
    void setBitDepth (BitDepth depth) { bitDepth = depth; }
    BitDepth getBitDepth() const { return bitDepth; }

    // ---- Modo dispositivo MME ----
    juce::StringArray getAvailableMMEDevices();
    void setMMEDeviceName (const juce::String& name);
    juce::String getMMEDeviceName() const { return mmeDeviceName; }
    juce::String getMMEStatusMessage() const { return mmeStatus; }

    // ---- Ganancia de lo que se transmite (dB) ----
    void setSendGainDb (float db) { sendGainDb.store (db); }
    float getSendGainDb() const { return sendGainDb.load(); }

    // ---- Monitoreo local ----
    enum class MonitorMode { original, transmitted, muted };
    void setMonitorMode (MonitorMode mode) { monitorMode.store (mode); }
    MonitorMode getMonitorMode() const { return monitorMode.load(); }

    // ---- Control común (Start/Stop) ----
    void start();
    void stop();
    bool getIsActive() const { return isActive.load(); }

    double getElapsedSeconds() const;
    float getPeakLevel (int channel) const { return channel == 0 ? peakL.load() : peakR.load(); }

private:
    // --- archivo ---
    juce::TimeSliceThread backgroundThread { "Recorder Writer Thread" };
    std::unique_ptr<juce::AudioFormatWriter::ThreadedWriter> threadedWriter;
    juce::CriticalSection writerLock;
    std::atomic<juce::AudioFormatWriter::ThreadedWriter*> activeWriter { nullptr };
    juce::File outputFile;
    BitDepth bitDepth = BitDepth::bit24;

    bool startFileRecording();
    void stopFileRecording();

    // --- dispositivo MME ---
    struct MMEPlaybackCallback : public juce::AudioIODeviceCallback
    {
        juce::AbstractFifo fifo { 1 << 16 };
        juce::AudioBuffer<float> ringBuffer { 2, 1 << 16 };

        void audioDeviceIOCallbackWithContext (const float* const* inputChannelData, int numInputChannels,
                                                float* const* outputChannelData, int numOutputChannels,
                                                int numSamples,
                                                const juce::AudioIODeviceCallbackContext& context) override;
        void audioDeviceAboutToStart (juce::AudioIODevice*) override {}
        void audioDeviceStopped() override {}

        void pushSamples (const juce::AudioBuffer<float>& source);
    };

    std::unique_ptr<juce::AudioDeviceManager> mmeDeviceManager;
    std::unique_ptr<MMEPlaybackCallback> mmeCallback;
    juce::String mmeDeviceName;
    juce::String mmeStatus { "Detenido" };

    bool startMMERouting();
    void stopMMERouting();

    // envía el bloque dado al destino activo (archivo o MME)
    void sendCurrentBlock (const juce::AudioBuffer<float>& toSend, int numSamples);

    // --- estado común ---
    OutputMode outputMode = OutputMode::toFile;
    std::atomic<bool> isActive { false };
    double currentSampleRate = 44100.0;
    std::atomic<juce::int64> samplesProcessed { 0 };

    std::atomic<float> sendGainDb { 0.0f };
    std::atomic<MonitorMode> monitorMode { MonitorMode::original };
    juce::AudioBuffer<float> sendScratchBuffer;

    std::atomic<float> peakL { 0.0f }, peakR { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (RecorderAudioProcessor)
};
