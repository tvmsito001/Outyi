#include "PluginEditor.h"

namespace
{
    const juce::Colour kBackground  { 0xff15161a };
    const juce::Colour kPanel       { 0xff1f2127 };
    const juce::Colour kAccent      { 0xffe0473f };
    const juce::Colour kAccentDim   { 0xff6e2622 };
    const juce::Colour kSelected    { 0xff3a3d47 };
    const juce::Colour kUnselected  { 0xff1f2127 };
    const juce::Colour kMonitorOn   { 0xff3ddc84 };
    const juce::Colour kMuteOn      { 0xffe0473f };
    const juce::Colour kText        { 0xffe8e8ea };
    const juce::Colour kTextDim     { 0xff8a8c94 };
    const juce::Colour kMeterGreen  { 0xff3ddc84 };
    const juce::Colour kMeterYellow { 0xffe8c547 };
    const juce::Colour kMeterRed    { 0xffe0473f };
}

RecorderAudioProcessorEditor::RecorderAudioProcessorEditor (RecorderAudioProcessor& p)
    : juce::AudioProcessorEditor (&p), processor (p)
{
    setSize (380, 400);

    // ---- Selector de modo de salida ----
    addAndMakeVisible (modeFileButton);
    addAndMakeVisible (modeMMEButton);
    modeFileButton.onClick = [this] { setMode (RecorderAudioProcessor::OutputMode::toFile); };
    modeMMEButton.onClick  = [this] { setMode (RecorderAudioProcessor::OutputMode::toMMEDevice); };

    // ---- REC ----
    addAndMakeVisible (recordButton);
    recordButton.setClickingTogglesState (true);
    recordButton.setColour (juce::TextButton::buttonColourId, kAccentDim);
    recordButton.setColour (juce::TextButton::textColourOffId, kText);
    recordButton.onClick = [this]
    {
        if (recordButton.getToggleState())
            processor.start();
        else
            processor.stop();
        updateControlsState();
    };

    addAndMakeVisible (timeLabel);
    timeLabel.setJustificationType (juce::Justification::centred);
    timeLabel.setColour (juce::Label::textColourId, kText);
    timeLabel.setFont (juce::Font (22.0f, juce::Font::bold));
    timeLabel.setText ("00:00", juce::dontSendNotification);

    // ---- Modo archivo ----
    addAndMakeVisible (filePathLabel);
    filePathLabel.setText (processor.getOutputFile().getFileName(), juce::dontSendNotification);
    filePathLabel.setColour (juce::Label::textColourId, kTextDim);
    filePathLabel.setFont (juce::Font (13.0f));
    filePathLabel.setJustificationType (juce::Justification::centredLeft);

    addAndMakeVisible (browseButton);
    browseButton.onClick = [this] { chooseFile(); };

    addAndMakeVisible (bitDepthLabel);
    bitDepthLabel.setColour (juce::Label::textColourId, kTextDim);
    bitDepthLabel.setFont (juce::Font (12.0f));

    addAndMakeVisible (bitDepthBox);
    bitDepthBox.addItem ("16-bit", 1);
    bitDepthBox.addItem ("24-bit", 2);
    bitDepthBox.addItem ("32-bit float", 3);
    bitDepthBox.setSelectedId (2, juce::dontSendNotification);
    bitDepthBox.onChange = [this]
    {
        switch (bitDepthBox.getSelectedId())
        {
            case 1: processor.setBitDepth (RecorderAudioProcessor::BitDepth::bit16);      break;
            case 3: processor.setBitDepth (RecorderAudioProcessor::BitDepth::bit32float); break;
            default: processor.setBitDepth (RecorderAudioProcessor::BitDepth::bit24);     break;
        }
    };

    // ---- Modo MME ----
    addAndMakeVisible (mmeDeviceBox);
    mmeDeviceBox.onChange = [this]
    {
        processor.setMMEDeviceName (mmeDeviceBox.getText());
    };

    addAndMakeVisible (refreshMMEButton);
    refreshMMEButton.onClick = [this] { refreshMMEDevices(); };

    addAndMakeVisible (mmeStatusLabel);
    mmeStatusLabel.setColour (juce::Label::textColourId, kTextDim);
    mmeStatusLabel.setFont (juce::Font (12.0f));
    mmeStatusLabel.setJustificationType (juce::Justification::centredLeft);

    // ---- Ganancia de envío ----
    addAndMakeVisible (gainLabel);
    gainLabel.setColour (juce::Label::textColourId, kTextDim);
    gainLabel.setFont (juce::Font (12.0f));

    addAndMakeVisible (gainSlider);
    gainSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    gainSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 60, 20);
    gainSlider.setRange (-24.0, 24.0, 0.1);
    gainSlider.setValue (0.0, juce::dontSendNotification);
    gainSlider.setTextValueSuffix (" dB");
    gainSlider.onValueChange = [this] { processor.setSendGainDb ((float) gainSlider.getValue()); };

    // ---- Monitoreo local ----
    addAndMakeVisible (monitorLabel);
    monitorLabel.setColour (juce::Label::textColourId, kTextDim);
    monitorLabel.setFont (juce::Font (12.0f));

    addAndMakeVisible (monitorOriginalButton);
    addAndMakeVisible (monitorTransmittedButton);
    addAndMakeVisible (monitorMuteButton);
    monitorOriginalButton.onClick    = [this] { setMonitor (RecorderAudioProcessor::MonitorMode::original); };
    monitorTransmittedButton.onClick = [this] { setMonitor (RecorderAudioProcessor::MonitorMode::transmitted); };
    monitorMuteButton.onClick        = [this] { setMonitor (RecorderAudioProcessor::MonitorMode::muted); };

    refreshMMEDevices();
    updateModeVisibility();
    updateControlsState();
    updateMonitorButtonColours();

    startTimerHz (30);
}

RecorderAudioProcessorEditor::~RecorderAudioProcessorEditor()
{
    stopTimer();
}

void RecorderAudioProcessorEditor::setMode (RecorderAudioProcessor::OutputMode mode)
{
    if (processor.getIsActive())
        return; // no cambiar de modo mientras está activo

    processor.setOutputMode (mode);
    updateModeVisibility();
}

void RecorderAudioProcessorEditor::setMonitor (RecorderAudioProcessor::MonitorMode mode)
{
    processor.setMonitorMode (mode);
    updateMonitorButtonColours();
}

void RecorderAudioProcessorEditor::updateMonitorButtonColours()
{
    const auto m = processor.getMonitorMode();

    monitorOriginalButton.setColour (juce::TextButton::buttonColourId,
        m == RecorderAudioProcessor::MonitorMode::original ? kSelected : kUnselected);

    monitorTransmittedButton.setColour (juce::TextButton::buttonColourId,
        m == RecorderAudioProcessor::MonitorMode::transmitted ? kMonitorOn : kUnselected);

    monitorMuteButton.setColour (juce::TextButton::buttonColourId,
        m == RecorderAudioProcessor::MonitorMode::muted ? kMuteOn : kUnselected);
}

void RecorderAudioProcessorEditor::refreshMMEDevices()
{
    auto devices = processor.getAvailableMMEDevices();
    mmeDeviceBox.clear (juce::dontSendNotification);

    for (int i = 0; i < devices.size(); ++i)
        mmeDeviceBox.addItem (devices[i], i + 1);

    auto current = processor.getMMEDeviceName();
    auto idx = devices.indexOf (current);
    if (idx >= 0)
        mmeDeviceBox.setSelectedId (idx + 1, juce::dontSendNotification);
    else if (devices.size() > 0)
    {
        mmeDeviceBox.setSelectedId (1, juce::dontSendNotification);
        processor.setMMEDeviceName (devices[0]);
    }
}

void RecorderAudioProcessorEditor::chooseFile()
{
    fileChooser = std::make_unique<juce::FileChooser> (
        "Elegi archivo de salida (WAV)",
        processor.getOutputFile(),
        "*.wav");

    const auto flags = juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles;

    fileChooser->launchAsync (flags, [this] (const juce::FileChooser& fc)
    {
        auto file = fc.getResult();
        if (file != juce::File())
        {
            processor.setOutputFile (file.withFileExtension ("wav"));
            filePathLabel.setText (processor.getOutputFile().getFileName(), juce::dontSendNotification);
        }
    });
}

void RecorderAudioProcessorEditor::updateModeVisibility()
{
    const bool isFileMode = processor.getOutputMode() == RecorderAudioProcessor::OutputMode::toFile;

    modeFileButton.setColour (juce::TextButton::buttonColourId, isFileMode ? kSelected : kUnselected);
    modeMMEButton.setColour  (juce::TextButton::buttonColourId, isFileMode ? kUnselected : kSelected);

    filePathLabel.setVisible (isFileMode);
    browseButton.setVisible (isFileMode);
    bitDepthLabel.setVisible (isFileMode);
    bitDepthBox.setVisible (isFileMode);

    mmeDeviceBox.setVisible (! isFileMode);
    refreshMMEButton.setVisible (! isFileMode);
    mmeStatusLabel.setVisible (! isFileMode);

    timeLabel.setVisible (isFileMode); // en MME el tiempo no importa
}

void RecorderAudioProcessorEditor::updateControlsState()
{
    const bool active = processor.getIsActive();

    recordButton.setButtonText (active ? "STOP" : "REC");
    recordButton.setColour (juce::TextButton::buttonColourId, active ? kAccent : kAccentDim);

    modeFileButton.setEnabled (! active);
    modeMMEButton.setEnabled (! active);
    browseButton.setEnabled (! active);
    bitDepthBox.setEnabled (! active);
    mmeDeviceBox.setEnabled (! active);
    refreshMMEButton.setEnabled (! active);
    // Ganancia y monitoreo se pueden cambiar en cualquier momento, incluso transmitiendo.
}

void RecorderAudioProcessorEditor::timerCallback()
{
    const float targetL = juce::jlimit (0.0f, 1.0f, processor.getPeakLevel (0));
    const float targetR = juce::jlimit (0.0f, 1.0f, processor.getPeakLevel (1));
    meterL += (targetL - meterL) * 0.35f;
    meterR += (targetR - meterR) * 0.35f;

    const double secs = processor.getElapsedSeconds();
    const int mins = (int) secs / 60;
    const int rem  = (int) secs % 60;
    timeLabel.setText (juce::String::formatted ("%02d:%02d", mins, rem), juce::dontSendNotification);

    if (processor.getOutputMode() == RecorderAudioProcessor::OutputMode::toMMEDevice)
        mmeStatusLabel.setText (processor.getMMEStatusMessage(), juce::dontSendNotification);

    repaint();
}

void RecorderAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBackground);

    auto bounds = getLocalBounds().toFloat();
    auto meterArea = bounds.removeFromRight (40).reduced (10.0f, 20.0f);

    auto drawMeter = [&] (juce::Rectangle<float> area, float level)
    {
        g.setColour (kPanel);
        g.fillRoundedRectangle (area, 4.0f);

        auto filled = area.withTop (area.getBottom() - area.getHeight() * level);
        const juce::Colour c = level > 0.9f ? kMeterRed : (level > 0.7f ? kMeterYellow : kMeterGreen);
        g.setColour (c);
        g.fillRoundedRectangle (filled, 4.0f);
    };

    auto meterL_area = meterArea.removeFromLeft (12.0f);
    meterArea.removeFromLeft (6.0f);
    auto meterR_area = meterArea.removeFromLeft (12.0f);

    drawMeter (meterL_area, meterL);
    drawMeter (meterR_area, meterR);

    g.setColour (kTextDim);
    g.setFont (10.0f);
    g.drawText ("RECORDER", getLocalBounds().removeFromTop (18).reduced (16, 0),
                juce::Justification::centredLeft);
}

void RecorderAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced (16);
    area.removeFromTop (14);   // espacio para el título dibujado en paint()
    area.removeFromRight (40); // reservado para los medidores

    // Selector de modo de salida
    auto modeRow = area.removeFromTop (30);
    modeFileButton.setBounds (modeRow.removeFromLeft (modeRow.getWidth() / 2).reduced (2));
    modeMMEButton.setBounds (modeRow.reduced (2));

    area.removeFromTop (12);

    // REC + tiempo
    auto top = area.removeFromTop (46);
    recordButton.setBounds (top.removeFromLeft (90).reduced (4));
    top.removeFromLeft (10);
    timeLabel.setBounds (top);

    area.removeFromTop (12);

    // Modo archivo
    auto fileRow = area.removeFromTop (28);
    filePathLabel.setBounds (fileRow.removeFromLeft (fileRow.getWidth() - 34));
    browseButton.setBounds (fileRow);

    area.removeFromTop (10);
    auto bitDepthRow = area.removeFromTop (26);
    bitDepthLabel.setBounds (bitDepthRow.removeFromLeft (70));
    bitDepthBox.setBounds (bitDepthRow);

    // Modo MME (comparte el mismo espacio que el bloque de archivo)
    auto mmeArea = fileRow.getUnion (bitDepthRow);
    auto mmeDeviceRow = mmeArea.removeFromTop (28);
    mmeDeviceBox.setBounds (mmeDeviceRow.removeFromLeft (mmeDeviceRow.getWidth() - 90));
    mmeDeviceRow.removeFromLeft (6);
    refreshMMEButton.setBounds (mmeDeviceRow);
    mmeStatusLabel.setBounds (bitDepthRow);

    area.removeFromTop (16);

    // Ganancia de envío
    gainLabel.setBounds (area.removeFromTop (16));
    area.removeFromTop (2);
    gainSlider.setBounds (area.removeFromTop (26));

    area.removeFromTop (16);

    // Monitoreo local
    monitorLabel.setBounds (area.removeFromTop (16));
    area.removeFromTop (2);
    auto monitorRow = area.removeFromTop (28);
    const int third = monitorRow.getWidth() / 3;
    monitorOriginalButton.setBounds (monitorRow.removeFromLeft (third).reduced (3));
    monitorTransmittedButton.setBounds (monitorRow.removeFromLeft (third).reduced (3));
    monitorMuteButton.setBounds (monitorRow.reduced (3));
}
