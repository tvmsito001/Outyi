#pragma once
#include <JuceHeader.h>
#include "PluginProcessor.h"

class RecorderAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer
{
public:
    explicit RecorderAudioProcessorEditor (RecorderAudioProcessor&);
    ~RecorderAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void chooseFile();
    void updateControlsState();
    void updateModeVisibility();
    void updateMonitorButtonColours();
    void refreshMMEDevices();
    void setMode (RecorderAudioProcessor::OutputMode mode);
    void setMonitor (RecorderAudioProcessor::MonitorMode mode);

    RecorderAudioProcessor& processor;

    // Selector de modo de salida
    juce::TextButton modeFileButton  { "Archivo" };
    juce::TextButton modeMMEButton   { "MME" };

    // Controles comunes
    juce::TextButton recordButton { "REC" };
    juce::Label timeLabel;

    // Modo archivo
    juce::Label filePathLabel;
    juce::TextButton browseButton { "..." };
    juce::ComboBox bitDepthBox;
    juce::Label bitDepthLabel { {}, "Bit depth" };

    // Modo MME
    juce::ComboBox mmeDeviceBox;
    juce::TextButton refreshMMEButton { "Actualizar" };
    juce::Label mmeStatusLabel;

    // Ganancia de envío
    juce::Slider gainSlider;
    juce::Label gainLabel { {}, "Ganancia envio" };

    // Monitoreo local
    juce::Label monitorLabel { {}, "Escuchar" };
    juce::TextButton monitorOriginalButton    { "Original" };
    juce::TextButton monitorTransmittedButton { "Transmision" };
    juce::TextButton monitorMuteButton        { "Mute" };

    std::unique_ptr<juce::FileChooser> fileChooser;

    float meterL = 0.0f, meterR = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (RecorderAudioProcessorEditor)
};
