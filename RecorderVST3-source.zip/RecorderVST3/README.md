# Recorder VST3 (64-bit)

Plugin de utilidad, original y de código abierto para vos, que graba el canal/bus
donde lo insertes a un archivo WAV. Formato **VST3, 64-bit**. Interfaz oscura y
minimalista: botón REC, selector de bit depth (16 / 24 / 32-bit float), medidor
de nivel L/R y contador de tiempo.

No usa ni contiene código de ningún plugin de terceros — es una implementación
nueva hecha con [JUCE](https://juce.com/), el framework estándar de la industria
para plugins de audio en C++.

## Requisitos para compilar (Windows)

- Visual Studio 2022 (Community alcanza) con el workload "Desktop development with C++"
- CMake 3.22 o superior (https://cmake.org/download/)
- Conexión a internet la primera vez (CMake descarga JUCE automáticamente)

## Cómo compilar

Abrí "Developer Command Prompt for VS 2022" (o una terminal normal si tenés
cmake en el PATH), parate en esta carpeta y corré:

```bat
cmake -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
```

La primera vez va a tardar varios minutos porque descarga JUCE (~500 MB).
Las siguientes compilaciones son mucho más rápidas.

Como el proyecto tiene `COPY_PLUGIN_AFTER_BUILD TRUE`, al terminar el build el
`.vst3` se copia solo a:

```
C:\Program Files\Common Files\VST3\Recorder.vst3
```

Si no se copió automáticamente (por permisos), lo encontrás en:

```
build\RecorderVST3_artefacts\Release\VST3\Recorder.vst3
```

y lo copiás manualmente a esa misma carpeta de `C:\Program Files\Common Files\VST3\`.

## Uso en Ableton Live

1. Forzá un rescan de plugins (Preferences > Plug-Ins > Rescan) si Live no lo
   detecta solo.
2. Insertá "Recorder" como efecto en el canal o bus que quieras capturar.
3. Elegí el modo arriba: **Archivo** o **MME**.
4. Apretá REC para empezar, STOP para terminar. El audio del canal sigue
   sonando normal en Live (el plugin no lo altera, solo lo copia).

### Modo Archivo

Elegí el archivo de salida con "..." y el bit depth (16 / 24 / 32-bit float).
Al grabar, escribe un WAV en esa ruta.

### Modo MME (para OBS, Discord, etc.)

Este modo NO graba a disco: envía el audio en tiempo real a un dispositivo
de salida MME de Windows, para que otro programa lo capture como si fuera
una tarjeta de sonido. Necesitás un dispositivo "virtual" instalado primero:

1. Instalá [VB-CABLE](https://vb-audio.com/Cable/) (gratis) si no lo tenés.
2. En el plugin, elegí el modo **MME**, y en el desplegable seleccioná
   "CABLE Input (VB-Audio Virtual Cable)". Si no aparece, apretá
   "Actualizar".
3. Apretá REC. El audio del canal ahora se envía en vivo a ese dispositivo.
4. En OBS: Fuentes > + > Captura de entrada de audio > elegí
   "CABLE Output (VB-Audio Virtual Cable)".
5. (Opcional) Si querés seguir escuchando ese mismo audio vos, activá
   "Escuchar este dispositivo" en Panel de Control > Sonido > Grabación >
   CABLE Output > Propiedades > pestaña Escuchar.

Nota: el dispositivo MME se abre al sample rate del proyecto de Live. Si
VB-CABLE no soporta ese sample rate exacto, vas a ver un mensaje de error
en el status del plugin — en ese caso proba cambiar el sample rate del
proyecto a 44100 o 48000 Hz, que son los más compatibles.

### Ganancia de envío y monitoreo local

Estos dos controles funcionan igual en modo Archivo y modo MME:

- **Ganancia envío** (slider, -24 a +24 dB): sube o baja el nivel de lo que
  se graba/transmite, independiente de lo que escuchás vos. Por defecto en
  0 dB (sin cambios).
- **Escuchar** (3 botones): elegí qué sale por tus parlantes/interfaz
  mientras el plugin está transmitiendo:
  - **Original**: escuchás el canal tal cual, sin la ganancia de envío
    aplicada (bypass total, como si el plugin no estuviera).
  - **Transmisión**: escuchás exactamente lo mismo que se está mandando
    (con la ganancia de envío ya aplicada).
  - **Mute**: no escuchás nada de este canal por tus parlantes/interfaz,
    pero la transmisión hacia el archivo o el dispositivo MME sigue activa.
    Usá esta opción si ya estabas escuchando el audio por otro lado (por
    ejemplo, activaste "Escuchar este dispositivo" en el CABLE Output de
    Windows) y no querés oírlo duplicado.

Estos dos controles se pueden cambiar en cualquier momento, incluso con
REC/transmisión activa.

## Estructura del proyecto

```
RecorderVST3/
  CMakeLists.txt          -> configuración de build (JUCE + VST3)
  Source/
    PluginProcessor.h/.cpp -> lógica de grabación (escritura WAV en segundo plano)
    PluginEditor.h/.cpp    -> interfaz gráfica minimalista
```

## Personalización rápida

- **Colores de la interfaz**: están todos como constantes al inicio de
  `PluginEditor.cpp` (`kBackground`, `kAccent`, etc.) — cambiando esos valores
  hex cambiás toda la paleta.
- **Tamaño de ventana**: `setSize (360, 220)` en el constructor de
  `PluginEditor.cpp`.
- **Nombre/fabricante del plugin**: en `CMakeLists.txt`, los campos
  `COMPANY_NAME`, `PLUGIN_MANUFACTURER_CODE` y `PRODUCT_NAME`.
